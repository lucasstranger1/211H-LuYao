#ifndef MAIN_MENU_H
#define MAIN_MENU_H
#include <QException>
#include <QDialog>
namespace Ui {
class main_menu;
}

class main_menu : public QDialog
{
    Q_OBJECT



public:
    explicit main_menu(QWidget *parent = nullptr);
    ~main_menu();
 void openUserProfile(const QString& studentEmail);

private slots:
    void on_pushButton_tutoring_4_clicked();

    void on_pushButton_meetAtutor_clicked();

   // void on_pushButton_account_4_clicked();

    void on_pushButton_account_2_clicked();



    void on_pushButton_account_5_clicked();

    void on_pushButton_tutoring_8_clicked();

    void on_pushButton_tutoring_9_clicked();

    void on_pushButton_ViewTutors_clicked();

    void on_pushButton_tutoring_12_clicked();

    void on_pushButton_account_6_clicked();

    void on_pushButton_tutoring_11_clicked();

    void on_pushButton_1_clicked();

    void on_pushButton_account_7_clicked();

    void on_pushButton_tutoring_14_clicked();

    void on_pushButton_tutoring_13_clicked();

    void on_pushButton_tutoring_2_clicked();

    void on_pushButton_tutoring_15_clicked();

    void on_pushButton_account_11_clicked();

    void on_pushButton_tutoring_25_clicked();

    void on_pushButton_tutoring_24_clicked();

    void on_pushButton_seachButton_clicked();

    void on_pushButton_account_8_clicked();

    void on_pushButton_tutoring_16_clicked();

    void on_pushButton_tutoring_17_clicked();

    void on_pushButton_ViewTutors_17_clicked();

    void on_pushButton_tutoring_28_clicked();

    void on_pushButton_tutoring_26_clicked();

    void on_pushButton_tutoring_31_clicked();

    void on_pushButton_tutoring_29_clicked();

    void on_pushButton_tutoring_30_clicked();



    void on_pushButton_tutoring_5_clicked();

    void on_checkBox_5_clicked();



    void on_checkBox_9_clicked();


    void on_checkBox_34_clicked();

    void on_pushButton_tutoring_6_clicked();

    void on_checkBox_2_clicked();

    void on_pushButton_tutoring_7_clicked();



    void on_pushButton_profile_clicked();

    void on_pushButton_tutoring_18_clicked();



    void on_checkBox_8_clicked();
    void on_pushButton_bookhimher_clicked();

private:
    Ui::main_menu *ui;
    int clickCount = 0;


};

#endif
