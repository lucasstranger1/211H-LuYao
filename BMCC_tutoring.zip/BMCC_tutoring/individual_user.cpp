#include "individual_user.h"



Individual_user::Individual_user(){

}

Individual_user::~Individual_user(){

}
