#ifndef LOGIN_WINDOW_H
#define LOGIN_WINDOW_H
#include <QDebug>
#include <QtSql>
#include <QFileInfo>
#include <QDialog>
#include "QtSql/qsqldatabase.h"
#include "regiter_window.h"
#include "main_menu.h"
class UserProfile;
namespace Ui {
class login_window;
}

class login_window : public QDialog
{
    Q_OBJECT

public:
    explicit login_window(QWidget *parent = nullptr);
    ~login_window();

private slots:

    void on_loginbutton_clicked();

    void on_Register_Button_clicked();

private:
    Ui::login_window *ui;

    regiter_window *R;
    main_menu *M;
    QSqlDatabase myDB;


};

#endif // LOGIN_WINDOW_H
