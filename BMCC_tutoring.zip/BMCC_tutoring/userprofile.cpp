#include "userprofile.h"

UserProfile::UserProfile(){

}

UserProfile::~UserProfile(){

}
