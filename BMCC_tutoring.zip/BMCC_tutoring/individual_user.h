#ifndef INDIVIDUAL_USER_H
#define INDIVIDUAL_USER_H

#include "ui_main_menu.h"
#include "userprofile.h"
#include <QLabel>
class Individual_user:public UserProfile{
public:
    std::string major;
    double gpa;
    int credits_taken;
    std::string ethnicity;
 void displayOnUI(Ui::main_menu* ui);
    Individual_user();
    ~Individual_user();

private:

};

#endif // INDIVIDUAL_USER_H
