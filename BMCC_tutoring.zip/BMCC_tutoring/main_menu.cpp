#include "main_menu.h"
#include "individual_user.h"
#include "ui_main_menu.h"
#include <QPushButton>
#include <QMessageBox>
#include <QFile>
#include <iostream>
#include <QString>
#include <QException>
#include <stdexcept>
#include <QDate>
main_menu::main_menu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::main_menu)
{
    ui->setupUi(this);
QObject::connect(ui->pushButton_bookhimher, &QPushButton::clicked, this, &main_menu::on_pushButton_bookhimher_clicked);
//QObject::connect(ui->pushButton_account_4, &QPushButton::clicked, this, &main_menu::on_pushButton_account_4_clicked);
}

main_menu::~main_menu()
{
    delete ui;
}




void main_menu::on_pushButton_tutoring_4_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void main_menu::on_pushButton_meetAtutor_clicked()
{
     ui->stackedWidget->setCurrentIndex(2);
}


//void main_menu::on_pushButton_account_4_clicked()
//{
//    ui->stackedWidget->setCurrentIndex(1);
//}


void main_menu::on_pushButton_account_2_clicked()
{ ui->stackedWidget->setCurrentIndex(1);

}




void main_menu::on_pushButton_account_5_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_8_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_9_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void main_menu::on_pushButton_ViewTutors_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}


void main_menu::on_pushButton_tutoring_12_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void main_menu::on_pushButton_account_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_11_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void main_menu::on_pushButton_1_clicked()
{
     ui->stackedWidget->setCurrentIndex(5);
}


void main_menu::on_pushButton_account_7_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_14_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_13_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_2_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_15_clicked()
{
     bool isChecked5 = ui->checkBox_5->isChecked();
     bool isChecked9 = ui->checkBox_9->isChecked();
     bool isChecked34 = ui->checkBox_34->isChecked();
     bool isChecked2 = ui->checkBox_2->isChecked();
     bool isChecked8 = ui->checkBox_8->isChecked();
     if (isChecked5)
     {
         ui->stackedWidget->setCurrentIndex(9);
     }
     else if(isChecked9)
     {
         ui->stackedWidget->setCurrentIndex(6);
     }
     else if(isChecked34)
     {
         ui->stackedWidget->setCurrentIndex(10);
     }
     else if(isChecked2)
     {
         ui->stackedWidget->setCurrentIndex(11);
     }
     else if(isChecked8)
     {
         ui->stackedWidget->setCurrentIndex(8);
     }
}


void main_menu::on_pushButton_account_11_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_25_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_24_clicked()
{
     ui->stackedWidget->setCurrentIndex(5);
}


void main_menu::on_pushButton_seachButton_clicked()
{
     QFile file("/Users/lucasyao/Documents/Documents - Lucas’s MacBook Pro/2023 Spring Semester/CSC211H/Honor project /BMCC_tutoring/classInfo.txt");

 QString className = ui->lineEdit_classNsubject->text();
     if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
         QTextStream in(&file);
         QString line;
         bool classFound = false;
         while (!in.atEnd()) {
             line = in.readLine();
             if (line.toLower().contains(className.toLower())) {
                 classFound = true;
                 break;
             }
         }
         file.close();
         if (classFound==true&&className.toLower() == "csc211h") {
             ui->stackedWidget->setCurrentIndex(3);
             QMessageBox::information(this, "Successful", "Found your class");
         }
         else if (classFound==true&&className.toLower() == "csc101") { // check if className is "CSC101"
                 ui->stackedWidget->setCurrentIndex(7);
                 QMessageBox::information(this, "Successful", "Found your class");
             } else {
                 QMessageBox::warning(this, "Failed", "Invalid input");
                 QMessageBox::information(this, "Failed", "Can't find your class!");

         }
     }
            qDebug() << "className =" << className;

     }




void main_menu::on_pushButton_account_8_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_16_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void main_menu::on_pushButton_tutoring_17_clicked()
{
     ui->stackedWidget->setCurrentIndex(2);
}


void main_menu::on_pushButton_ViewTutors_17_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}


void main_menu::on_pushButton_tutoring_28_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
}


void main_menu::on_pushButton_tutoring_26_clicked()
{
    ui->stackedWidget->setCurrentIndex(8);
}


void main_menu::on_pushButton_tutoring_31_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(2);
}


void main_menu::on_pushButton_tutoring_29_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_30_clicked()
{
     ui->stackedWidget_2->setCurrentIndex(1);
}


void main_menu::on_pushButton_tutoring_5_clicked()
{
     ui->stackedWidget->setCurrentIndex(5);
}




void main_menu::on_checkBox_5_clicked()
{
     clickCount++;

     // If the click count is even, set the checkbox state to unchecked
     if (clickCount % 2 == 0) {
         ui->checkBox_5->setCheckState(Qt::Unchecked);
     }
}



void main_menu::on_checkBox_9_clicked()
{
     clickCount++;

     // If the click count is even, set the checkbox state to unchecked
     if (clickCount % 2 == 0) {
         ui->checkBox_9->setCheckState(Qt::Unchecked);
}

}



void main_menu::on_checkBox_34_clicked()
{     clickCount++;

// If the click count is even, set the checkbox state to unchecked
if (clickCount % 2 == 0) {
         ui->checkBox_34->setCheckState(Qt::Unchecked);
}


}


void main_menu::on_pushButton_tutoring_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
}


void main_menu::on_checkBox_2_clicked()
{
    clickCount++;

    // If the click count is even, set the checkbox state to unchecked
    if (clickCount % 2 == 0) {
         ui->checkBox_2->setCheckState(Qt::Unchecked);
    }

}


void main_menu::on_pushButton_tutoring_7_clicked()
{

  ui->stackedWidget->setCurrentIndex(5);}




void main_menu::on_pushButton_profile_clicked()
{
   ui->stackedWidget->setCurrentIndex(0);
    Individual_user myuser;
    myuser.name="Lucas";
    myuser.email="Lucas@gmail.com";
    myuser.major="Computer Science";
    myuser.birthday = QDate(1900, 5, 14);

    myuser.gpa=4.0;
    double gpa = myuser.gpa;
    QString gpaText = QString::number(gpa,'f',1);
    myuser.password="123";
    myuser.credits_taken=30;
    int credits= myuser.credits_taken;
    QString creditsText=QString::number(credits);
    myuser.ethnicity="Asian";

    ui->label_name->setText(QString::fromStdString(myuser.name));
    ui->label_username->setText(QString::fromStdString(myuser.email));
    ui->label_password->setText(QString::fromStdString(myuser.password));
    ui->label_GPA->setText(gpaText);
    ui->label_credits->setText(creditsText);
    ui->label_Ethnicity->setText(QString::fromStdString( myuser.ethnicity));
    ui->label_major->setText(QString::fromStdString(myuser.major));
    QString dateOfBirthText = myuser.birthday.toString("yyyy-MM-dd"); // Format the date as desired, e.g., "yyyy-MM-dd"
    ui->label_DOB->setText(dateOfBirthText);
}


void main_menu::on_pushButton_tutoring_18_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);
}




void main_menu::on_checkBox_8_clicked()
{
     clickCount++;

     // If the click count is even, set the checkbox state to unchecked
     if (clickCount % 2 == 0) {
         ui->checkBox_8->setCheckState(Qt::Unchecked);
     }

}

void main_menu::on_pushButton_bookhimher_clicked(){
      ui->stackedWidget->setCurrentIndex(6);
}
