#ifndef USERPROFILE_H
#define USERPROFILE_H
#include "QtCore/qdatetime.h"
#include <iostream>
#include <QString>

class UserProfile{
    struct date{
        int day;
        int month;
        int year;
    };
public:
    std::string username;
    std::string email;
    std::string password;
    std::string name;
    std::string gender;
    QDate birthday;
    int phone;
    std::string address;

    UserProfile();
    ~UserProfile();

};
#endif // USERPROFILE_H
