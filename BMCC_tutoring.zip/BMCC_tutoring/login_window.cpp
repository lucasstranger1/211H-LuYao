#include "login_window.h"
#include "QtSql/qsqldatabase.h"
#include "ui_login_window.h"
#include <QMessageBox>
#include "regiter_window.h"
#include <QTextStream>
#include <vector>
#include <QFile>
#include <string>
#include <fstream>
#include <QPixmap>

#define Path_to_DB "/Users/lucasyao/Documents/Documents - Lucas’s MacBook Pro/2023 Spring Semester/CSC211H/Honor project /Database/Accounts.db"





login_window::login_window(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::login_window)/*, M(nullptr)*/

{
    ui->setupUi(this);
    QSqlDatabase myDB;
    myDB = QSqlDatabase::addDatabase("QSQLITE");
    myDB.setDatabaseName(Path_to_DB);
    QFileInfo checkFile(Path_to_DB);

    if(checkFile.isFile()){
        if(myDB.open()){
            ui->label_dbStatue->setText("[+]DateBase connected :) ");
        }
    }else{
        ui->label_dbStatue->setText("[!]DateBase NOT connected :( ");
    }



}

login_window::~login_window()
{
    delete ui;
    delete M;
    delete R;
}
void login_window::on_loginbutton_clicked()
{       /* if (M != nullptr) {
        delete M; // Delete the previous main_menu object if it exists
    }*/
    M = new main_menu(this);

    QString email = ui->lineEdit_Email->text();
    QString password = ui->lineEdit_Password->text();

    ui->lineEdit_Email->setText("");
    ui->lineEdit_Password->setText("");

    if(!myDB.isOpen()){
        qDebug() << "No connection to db :(";
    }
    QSqlQuery qry;
    if(qry.exec("SELECT * FROM Users WHERE email=\'"+email+"\'AND password=\'"+password+"\'")){
        if(qry.next()){

            QString msg = "userID = " + qry.value(0).toString()+"\n"+"Name = " + qry.value(1).toString()+" "+ qry.value(2).toString()+"\n"+"DOB = " + qry.value(4).toString()+"\n";
            QString usrName = qry.value(9).toString();
            QMessageBox::information(this, "login was successful",msg);
            M->show(); // Show the new main_menu window
            close();
        }else{
            QMessageBox::information(this,"Warning", "Wronge email or password");
        }
    }

//    QString studentEmail = ui->lineEdit_Email->text();
//    QString password = ui->lineEdit_Password->text();
//    QFile file("/Users/lucasyao/Documents/Documents - Lucas’s MacBook Pro/2023 Spring Semester/CSC211H/Honor project /BMCC_tutoring/userInfo.txt");

//    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
//        QTextStream in(&file);
//        QString line;
//        bool match = false;
//        while (!in.atEnd()) {
//            line = in.readLine();
//            QStringList fields = line.split(",");
//            if (fields.size() == 3 && fields.at(1) == studentEmail && fields.at(2) == password) {
//                match = true;
//                break;
//            }
//        }
//        if (match) {
//            QMessageBox::information(this, "Login", "Login successfully");
//            file.close();

//            close(); // Close the current login_window




//        } else {
//            QMessageBox::warning(this, "Login", "Username or password incorrect");
//        }
//        file.close();
//    } else {
//        QMessageBox::warning(this, "Error", "Failed to open file");
//    }

}



void login_window::on_Register_Button_clicked()
{
   R = new regiter_window(this);
   R->show();

}



