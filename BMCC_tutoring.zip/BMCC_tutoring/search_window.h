#ifndef SEARCH_WINDOW_H
#define SEARCH_WINDOW_H

#include <QDialog>

namespace Ui {
class search_window;
}

class search_window : public QDialog
{
    Q_OBJECT

public:
    explicit search_window(QWidget *parent = nullptr);
    ~search_window();

private:
    Ui::search_window *ui;
};

#endif // SEARCH_WINDOW_H
