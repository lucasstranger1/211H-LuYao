#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QPixmap>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)

{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
    delete login_window;
}


void MainWindow::on_Login_Button_clicked()
{
//    login_window login_window;
//    login_window.setModal(true);
//    login_window.exec();
    close();
    login_window = new class login_window(this);
    login_window->show();

}

