#ifndef REGITER_WINDOW_H
#define REGITER_WINDOW_H

#include "QtCore/qregularexpression.h"
#include "ui_regiter_window.h"
#include <QDialog>

namespace Ui {
class regiter_window;
}

class regiter_window : public QDialog
{
    Q_OBJECT

public:
    explicit regiter_window(QWidget *parent = nullptr);
    ~regiter_window();
    static QRegularExpression lowercase_regex;
    static QRegularExpression uppercase_regex;
    static QRegularExpression digit_regex;
    static  QRegularExpression special_regex;
    QString getName() const;
    QString getStudentEmail() const;
    QString getPassword() const;
private slots:


    //void on_pushButton_clicked();

    void on_pushButton_cancel_clicked();
    void on_pushButton_register_clicked();

protected:

private:
    Ui::regiter_window *ui;

};


#endif // REGITER_WINDOW_H
