#include "regiter_window.h"
#include "ui_regiter_window.h"
#include <QTextStream>
#include <QMessageBox>
#include <QFile>
#include <QFileDialog>
#include <QRegularExpression>
regiter_window::regiter_window(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::regiter_window)
{
    ui->setupUi(this);
   connect(ui->pushButton_register, SIGNAL(clicked()), this, SLOT(on_pushButton_clicked()));
   connect(ui->pushButton_cancel, &QPushButton::clicked, this, &::regiter_window::on_pushButton_cancel_clicked);

}

regiter_window::~regiter_window()
{
    delete ui;
}

bool isValidEmail(const QString& email) {
    // Declare a static QRegularExpression object in your class or function
    static QRegularExpression emailPattern("^[A-Za-z0-9._%+-]+@(stu\\.bmcc\\.cuny\\.edu|[A-Za-z0-9.-]+\\.[A-Za-z]{2,})$");



    return emailPattern.match(email).hasMatch();
}
QString regiter_window::getName() const
{
    return ui->textEdit_name->toPlainText();
}

QString regiter_window::getStudentEmail() const
{
    return ui->textEdit_studentEmail->toPlainText();
}

QString regiter_window::getPassword() const
{
    return ui->textEdit_password->toPlainText();
}
    QRegularExpression regiter_window::uppercase_regex("[A-Z]");
    QRegularExpression  regiter_window::lowercase_regex("[a-z]");
    QRegularExpression  regiter_window::digit_regex("\\d");
    QRegularExpression  regiter_window::special_regex("[^a-zA-Z0-9]");

    bool is_valid_password(const QString& password)
    {
        int length = password.length();

        // Check length
        if (length < 8 || length > 16)
            return false;

        // Check for at least one uppercase letter

        if (!password.contains(regiter_window::uppercase_regex))
            return false;

        // Check for at least one lowercase letter

        if (!password.contains(regiter_window::lowercase_regex))
            return false;

        // Check for at least one digit

        if (!password.contains(regiter_window::digit_regex))
            return false;

        // Check for at least one special character

        if (!password.contains(regiter_window::special_regex))
            return false;

        return true;

}





void regiter_window::on_pushButton_cancel_clicked()
{
    close();
}


void regiter_window::on_pushButton_register_clicked()
{
QFile file("/Users/lucasyao/Documents/Documents - Lucas’s MacBook Pro/2023 Spring Semester/CSC211H/Honor project /BMCC_tutoring/userInfo.txt");

                   QString name = ui->textEdit_name->toPlainText();
                   QString studentEmail = ui->textEdit_studentEmail->toPlainText();
                   QString password = ui->textEdit_password->toPlainText();


    try {
            if (!is_valid_password(password)|| !isValidEmail(studentEmail)) {
            throw std::runtime_error("Invalid Password/Email");
        }

        if (file.open(QIODevice::ReadWrite| QIODevice::Append | QIODevice::Text)) {
            QTextStream in(&file);
            QString userInfo = QString("%1,%2,%3\n").arg(name,studentEmail, password);
            QTextStream stream(&file);
            stream << userInfo << Qt::endl;
            file.close();
            QMessageBox::information(this,"Register Sucessfully", "You have created your account!");
            close();
        }
    }
    catch(std::runtime_error& excpt) {
        QMessageBox::warning(this,"failed","Invalid password/Email, Must be contained Upper+Lower Cases and at least one special character, and the length should >= 8");
    }
}

